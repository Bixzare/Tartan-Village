
  # Tartan Village

  This is a code bundle for Tartan Village. The original project is available at https://www.figma.com/design/dfL44gLeGd1qPprx2GfRar/Tartan-Village.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  