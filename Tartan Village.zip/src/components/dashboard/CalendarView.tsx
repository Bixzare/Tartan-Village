import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Calendar } from '../ui/calendar';
import { Badge } from '../ui/badge';
import { CalendarIcon, Clock } from 'lucide-react';
import { useState } from 'react';

interface Event {
  id: string;
  title: string;
  date: Date;
  time: string;
  category: string;
  location: string;
}

const upcomingEvents: Event[] = [
  {
    id: '1',
    title: 'International Cultural Festival',
    date: new Date(2025, 9, 25),
    time: '2:00 PM - 6:00 PM',
    category: 'Events',
    location: 'Main Campus Quad'
  },
  {
    id: '2',
    title: 'Guest Lecture: Innovation in Digital Age',
    date: new Date(2025, 9, 27),
    time: '4:00 PM - 5:30 PM',
    category: 'Events',
    location: 'Auditorium Hall A'
  },
  {
    id: '3',
    title: 'Homecoming Week Kickoff',
    date: new Date(2025, 9, 28),
    time: '6:00 PM - 9:00 PM',
    category: 'Events',
    location: 'Student Center'
  },
  {
    id: '4',
    title: 'Financial Aid Application Deadline',
    date: new Date(2025, 9, 31),
    time: '11:59 PM',
    category: 'Announcements',
    location: 'Online'
  },
  {
    id: '5',
    title: 'Career Fair',
    date: new Date(2025, 10, 5),
    time: '10:00 AM - 4:00 PM',
    category: 'Internships',
    location: 'Sports Complex'
  },
  {
    id: '6',
    title: 'Research Symposium',
    date: new Date(2025, 10, 12),
    time: '9:00 AM - 5:00 PM',
    category: 'Spotlight',
    location: 'Science Building'
  }
];

const categoryColors: Record<string, string> = {
  Internships: 'bg-blue-100 text-blue-800',
  Events: 'bg-green-100 text-green-800',
  Announcements: 'bg-orange-100 text-orange-800',
  Spotlight: 'bg-purple-100 text-purple-800'
};

export function CalendarView() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const selectedDateEvents = upcomingEvents.filter(
    event => selectedDate && 
    event.date.getDate() === selectedDate.getDate() &&
    event.date.getMonth() === selectedDate.getMonth() &&
    event.date.getFullYear() === selectedDate.getFullYear()
  );

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1>Calendar</h1>
        <p className="text-gray-600 mt-1">View upcoming events and important dates</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5" />
              Event Calendar
            </CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="rounded-md border"
            />
          </CardContent>
        </Card>

        {/* Events for Selected Date */}
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedDate ? formatDate(selectedDate) : 'Select a Date'}
            </CardTitle>
            <p className="text-sm text-gray-600">
              {selectedDateEvents.length > 0 
                ? `${selectedDateEvents.length} event${selectedDateEvents.length > 1 ? 's' : ''}` 
                : 'No events'}
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            {selectedDateEvents.length > 0 ? (
              selectedDateEvents.map((event) => (
                <div key={event.id} className="p-3 border rounded-lg">
                  <Badge className={categoryColors[event.category]} variant="outline">
                    {event.category}
                  </Badge>
                  <h4 className="mt-2 mb-1">{event.title}</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                    <Clock className="w-3 h-3" />
                    <span>{event.time}</span>
                  </div>
                  <p className="text-sm text-gray-600">{event.location}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">
                No events scheduled for this date
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Events List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            All Upcoming Events
          </CardTitle>
          <p className="text-sm text-gray-600">Complete list of scheduled events</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {upcomingEvents
              .sort((a, b) => a.date.getTime() - b.date.getTime())
              .map((event) => (
                <div key={event.id} className="flex items-start justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={categoryColors[event.category]} variant="outline">
                        {event.category}
                      </Badge>
                    </div>
                    <h4 className="mb-1">{event.title}</h4>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <CalendarIcon className="w-3 h-3" />
                        <span>{formatDate(event.date)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{event.time}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{event.location}</p>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
